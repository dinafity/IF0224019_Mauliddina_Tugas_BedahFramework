<?php

Route::post('/event/store', [EventController::class, 'store']);