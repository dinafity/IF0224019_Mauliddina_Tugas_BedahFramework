<?php

class Event
{
    protected $table = 'events';

    protected $fillable = [
        'nama_event',
        'tanggal',
        'lokasi',
        'kuota',
    ];
}