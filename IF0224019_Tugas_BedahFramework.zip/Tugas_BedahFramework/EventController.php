<?php

class EventController
{
    public function store($request)
    {
        $validatedData = $request->validate([
            'nama_event' => 'required|string|max:255',
            'tanggal'    => 'required|date',
            'lokasi'     => 'required|string',
            'kuota'      => 'required|integer|min:1',
        ]);

        Event::create($validatedData);

        return redirect()->back()->with('success', 'Event berhasil ditambahkan!');
    }
}